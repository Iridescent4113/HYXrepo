<!-- ppt-master-schema: design-spec/v1 -->
# AI Metabolic Kickoff - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | AI＋代谢管理：内部启动与工作分配 |
| Canvas Format | PPT 16:9, 1280×720 |
| Page Count | 18 |
| Primary Language | zh-CN |
| Target Audience | PDT负责人、产品设计、后端数据、客户端、算法、临床、QA合规与运营成员 |
| Communication Intent | 统一首期范围和安全边界，解释软件协作链路，落实岗位交付、日期、依赖和验收 |
| Desired Audience Outcome | 与会者能够确认自己负责的交付物、计划截止时间、验收证据和升级对象，并落实启动资源 |
| Core Message / Ask / Action | 从零启动，12周内启动CGM与医生复核的受控试点；关键依赖必须先落实，未验证模型保持影子运行 |
| Delivery Context | 现场内部项目启动会讲解为主，约25分钟；会后独立阅读与岗位交接为辅 |
| Artifact Afterlife | GitHub归档、工作分配、周会查阅及计划基线评审 |
| Reading Mode | balanced |
| Content Strategy | balanced default；按启动会重组与概括现有方案，不添加实际进展、临床效果或虚构人名 |
| Design Style | 自由设计，交付导向的工程启动会；custom |
| Formula Policy | text-only |
| AI Image Acquisition Path | not applicable |
| Generation Mode | continuous |
| Spec Refinement | disabled |
| Speaker Notes | enabled — 用户委托整体决策，采用final Stage-2 proactive policy |
| Custom Animations | disabled — final Stage-2 proactive policy；保留默认页间过渡 |
| Narration Audio | disabled — final Stage-2 proactive policy |
| Created Date | 2026-10-13 |

Stage 1: 用户已明确委托当前代理完成全部沟通与设计决策。选择 free_design，无模板安装，无UI结果文件。岗位负责人为待指派角色。

Stage 2: 比较三个完整方向后选择方向0“交付闭环”：pyramid＋instructional组织目标→链路→责任→门槛→行动，swiss-minimal负责网格与留白，editorial负责任务与证据层级；图像候选为minimalist-swiss几何化、类似工程看板的严谨处理，但本项目选择none图像来源。方向1“技术走读”用instructional＋blueprint与blueprint图像候选，更适合技术深潜而较弱于组织分配。方向2“项目参考手册”用briefing＋editorial与editorial图像候选，便于查阅但现场动员较弱。三个方向都保留深蓝青绿配色、中文无衬线标题与正文、无图标和18页容量，差异来自整体信息架构与阅读节奏。上述选择是用户明确委托下的AI决定，不是伪造用户UI确认。

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280×720 |
| viewBox | `0 0 1280 720` |
| Margins | 左右56px，上下40px；页脚独立 |
| Content Area | 标题下方到页脚上方；表格与流程有独立呼吸空间 |

## III. Visual Theme

### Theme Style

- **Mode**: custom
- **Mode References**: pyramid, instructional
- **Mode Behavior**: 开篇明确12周试点目标，按采集→决策→审核干预逐层解释；随后把机制转成交付责任、DCP门槛与本周行动。
- **Visual style**: custom
- **Visual Style References**: swiss-minimal, editorial
- **Visual Style Behavior**: 大面积留白、精确矩形区域与细分隔线；目标与收束页使用非对称大字，模块页用有序链路，责任与日期页采用可扫描记录网格；不使用装饰阴影、圆角卡片泛滥或模拟产品截图。
- **Theme**: 深蓝结构与青绿主路径，谨慎使用暖色标识依赖和待确认事项
- **Tone**: 清晰、务实、可执行，区分计划目标与实际状态

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| Background | #F4F7FA | 主页面背景 |
| Secondary background | #FFFFFF | 清晰记录区 |
| Primary | #132E43 | 标题、章节深色区域 |
| Accent | #087F8C | 关键路径、重点和动作 |
| Secondary accent | #D78B42 | 拟议计划、待确认提示 |
| Body text | #183247 | 正文 |
| Muted | #5A6E7D | 次级说明 |
| Grid | #D9E3EA | 表格与分隔 |
| Inverse | #FFFFFF | 深色区域文字 |
| Warning | #A65B13 | 依赖和限制说明 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 无衬线，粗体，对齐明确 | Noto Sans CJK SC | Arial | Microsoft YaHei, sans-serif |
| Body | 无衬线，常规字重，可投屏 | Noto Sans CJK SC | Arial | Microsoft YaHei, sans-serif |

- **Title stack**: Noto Sans CJK SC, Microsoft YaHei, Arial
- **Body stack**: Noto Sans CJK SC, Microsoft YaHei, Arial

字体修订依据：原生PDF渲染时Microsoft YaHei替换导致部分中文字形缺失，改用执行环境已安装的Noto Sans CJK SC并重新验证。PPTX不嵌入字体，另提供PDF供稳定阅读。

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 24 |
| Title | 38 |
| Subtitle | 28 |
| Lead | 28 |
| Annotation | 18 |
| Label | 20 |
| Footnote | 14 |
| Hero | 84 |
| Cover | 56 |

## V. Layout Principles

### Page Structure

- **Header area**: 小章节标记与断言式页标题；正文页保持稳定导航位置。
- **Content area**: 一页一个核心交付问题；按关系选流图、分区解释或表格。相邻模块页保持合理的任务结构一致性，其余页面变化拓扑。
- **Footer area**: 项目简称、来源/规划性质与页码；深色背景上使用反色。

### Spacing Specification

| Element | Current Project |
| --- | --- |
| Safe margin | 56px |
| Content block gap | 24–32px |
| Icon-text gap | 无图标 |

禁止把未来日期、计划百分比和容量假设包装成已验证结果。页面上标记“计划基线”“拟议验收”“待指派”；公开发布与疗效证明保留在后续单独决策中。

## VI. Icon Usage Specification

- **Primary bundled library**: none
- 本项目以文字、连线和基本形状承担表达，不准备图标资源。

| Icon | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Layout pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

图像来源 none。全部页面使用可编辑文字、矩形、线条和流程结构，不使用模拟CGM曲线。

## IX. Content Outline

### Part 1: Goal and Scope

#### Slide 01 - 项目启动
- **Audience move**: 从宽泛AI项目概念转为12周试点的共同目标。
- **Layout**: 非对称大字封面，右侧12周目标与日期，底部五步服务链。
- **Title**: AI＋代谢管理
- **Core message**: 用12周跑通CGM、医生复核与行为反馈的受控试点。
- **Cover impact**: 12周这一明确时间约束成为钩子；把采集到反馈的闭环作为贯穿全稿的几何主线。
- **Content**: 内部启动与工作分配；中国大陆·医疗机构参与；2026-10-19拟启动；2027-01-10前启动试点；CGM→画像解释→医生复核→行为建议→反馈；方案v0.2，2026-10-13。
- **Data class**: scenario；未来日期和周数为条件性计划。

#### Slide 02 - 从零起步
- **Audience move**: 明确现状，并知道计划成立依赖哪些资源。
- **Layout**: 左侧0%现状；右侧已确认与待落实两组短说明。
- **Title**: 当前从零起步，先落实四项关键资源
- **Core message**: 真实开发进度0%，训练数据预期到位；时间表成立取决于团队、机构、接入与授权。
- **Content**: 已确认：中国大陆、医疗机构参与、近期训练数据、约3个月试点；待落实：合作科室与临床负责人、技术团队与预算、CGM厂商与接口、训练数据字典及用途许可；建议7–9名全职技术产品人员，临床与合规另配；岗位姓名待指派。
- **Data class**: scenario；7–9人为资源建议，0%为用户确认的产品基线。

#### Slide 03 - 首期范围
- **Audience move**: 分清首期必做、验证后开放和后续扩展。
- **Layout**: 三个有层级的纵向分区，底部人群与边界说明。
- **Title**: 首期聚焦血糖管理闭环，能力分层开放
- **Core message**: 优先合适成年人受控试点，不将所有人群套用同一干预策略。
- **Content**: 必做：一家CGM、曲线与质量、基础画像、医生审核、建议反馈；验证后开放：自有模型、专业智能体、个性化排序；后续：穿戴设备、睡眠活动、检验、多病程路径；临床负责人确认首期人群，复杂/特殊人群走专门路径；CGM不单独诊断，不提供药物调整或急救保障。

### Part 2: Software and Workstreams

#### Slide 04 - 软件闭环
- **Audience move**: 理解模块边界、数据方向和医生审查位置。
- **Layout**: 两行闭环流程，上行采集/质量/画像，下行证据/干预/医生/用户；外侧临床规则与反馈路径。
- **Title**: 三个业务模块，共用一个可追溯闭环
- **Core message**: 原始数据和结构化事实驱动建议，临床规则及医生审核把关。
- **Content**: CGM与资料→适配与质量→特征画像→自有模型/审定规则→证据包→智能体候选→合并安全检查→医生审核→患者反馈；权限、授权、版本、审计贯穿；模块化后端＋独立模型服务，患者端＋医生Web；新穿戴设备接适配层。
- **Visualization**: 按数据依赖连接节点，患者反馈回到画像；临床规则独立检查候选动作。

#### Slide 05 - 数据任务
- **Audience move**: 后端和数据角色明确D01–D03交付与验收。
- **Layout**: 左侧标准观测契约要点，右侧任务记录三行。
- **Title**: 数据工作流先交付真实接入与正确性
- **Core message**: 接入可用只是起点，时间、单位、去重和恢复必须可验证。
- **Content**: D01 后端：授权/绑定/原始落库，11-29前真实链路；D02 后端＋数据：标准观测/去重/补拉/质量，12-20前场景通过；D03 客户端＋后端：曲线/查询/同步监控，12-20前追溯正确。字段：来源设备、值与单位、采样/接收时间、质量、授权与版本；预留多源适配器；数据工作包20%。
- **Visualization**: data-deliverables为记录表，左侧字段为分组说明。
- **Native-ready**: data-deliverables=no
- **Data class**: scenario；日期和20%为计划权重。

#### Slide 06 - 模型任务
- **Audience move**: 算法角色知道训练先决条件、任务与开放门槛。
- **Layout**: 统计→画像→任务模型→语言解释四层；下方三项交付记录。
- **Title**: 先建立可解释基线，再验证自有模型
- **Core message**: AI解释使用结构化证据；模型未达门槛保持离线或影子运行。
- **Content**: M01 算法＋临床：统计/规则/画像基线，12-20；M02 算法：首轮训练与独立评估，12-27；M03 算法＋后端：解释/模型服务/版本/降级，12-27。训练前核查许可、标签、代表性；按用户隔离并保留时间外测试；数字由上游计算；决策工作包20%。
- **Visualization**: model-deliverables为三行记录表，能力分层是有序关系。
- **Native-ready**: model-deliverables=no
- **Data class**: scenario；日期和权重为计划。

#### Slide 07 - 智能体干预
- **Audience move**: 理解智能体只产生候选建议，统一审查后才发给患者。
- **Layout**: 四个专业角色汇入一条合并审查路径，底部权限说明。
- **Title**: 多智能体协作，最终只输出一套一致建议
- **Core message**: 硬规则独立于LLM，无法解决的冲突进入人工复核。
- **Content**: 数据解释、饮食、活动、作息依从性→合并去重与排序→独立安全规则→医生审核→一套建议；默认每天1–3项（可配置）；缺失睡眠/餐食背景不做确定归因；不修改药物、不写原始数据、不自动训练；候选附证据、禁忌和有效期。
- **Data class**: scenario；1–3项为拟议频率。

#### Slide 08 - 用户端与医生端
- **Audience move**: 客户端、后端和临床角色明确U01–U03验收。
- **Layout**: 患者与医生双泳道，上方两条产品路径，下方三项交付。
- **Title**: 患者可理解，医生可审核，建议可追溯
- **Core message**: 个性化建议先审后发，草稿和过期内容不得投递。
- **Content**: 患者：授权→资料与风险问卷→曲线/画像→建议选择→反馈；医生：授权患者列表→证据→批准/编辑/拒绝→异常处置；U01 客户端12-20；U02 后端＋客户端＋临床12-27；U03 算法＋临床12-27影子链路；用户与干预工作包15%；建议保留审核、投递、确认、过期状态。
- **Data class**: scenario；日期与15%为计划。

### Part 3: Ownership and Plan

#### Slide 09 - 组织与责任
- **Audience move**: 找到投资、交付、技术和临床决策的负责人。
- **Layout**: 上方IPMT与PDT层级，下方职责分组；责任人待具名。
- **Title**: PDT统筹交付，技术与临床分别守住门槛
- **Core message**: 任命具名负责人，跨岗位协作不替代责任归属。
- **Content**: IPMT批准范围、预算、DCP；PDT协调依赖与周报；产品设计负责PRD原型；技术负责架构与接入；算法负责标签/评估/版本；临床负责人群、禁忌和复核；QA合规负责验证与准入；运营负责招募支持；建议技术产品7–9人，临床另配；复核容量按患者×建议×审核时间测算。
- **Data class**: scenario；人数为资源建议。

#### Slide 10 - 协作任务矩阵
- **Audience move**: 对关键交付识别一个主责角色与协作、验收角色。
- **Layout**: 记录表：交付/主责/协作/验收/计划完成；采用五列六行。
- **Title**: 每项关键交付都有主责、协作与验收人
- **Core message**: 角色是建议分配，会上具名；验收不等于开发者自签。
- **Content**: PRD与首期范围 产品主责/临床技术协作/IPMT验收11-15；CGM正确链路 技术主责/数据客户端协作/QA验收12-20；画像与模型 算法主责/临床后端协作/临床＋QA验收12-27；医生审核闭环 技术主责/客户端临床协作/临床＋QA验收12-27；试点准入 临床主责/合规运营协作/机构授权方批准12-27；试点启动 运营主责/PDT临床协作/PDT＋临床验收01-10。
- **Visualization**: ownership-matrix为角色与交付记录表；不是已经具名的RACI批准记录。
- **Native-ready**: ownership-matrix=no
- **Data class**: scenario；角色及日期为待确认的责任方案。

#### Slide 11 - IPD里程碑
- **Audience move**: 区分阶段交付、DCP决策与计划完成度。
- **Layout**: 六段等宽有序阶段，三段上行三段下行；日期作为标签，不按时长缩放。
- **Title**: 12周启动试点，14周完成首轮复盘
- **Core message**: DCP按证据决定进入下一阶段，时间到不自动过关。
- **Content**: W1–2 10-19～11-01 概念DCP1 10%；W3–4 11-02～11-15 计划DCP2 25%；W5–8 11-16～12-13 开发TR2/3 60%；W9–10 12-14～12-27 验证DCP3 80%；W11–12 12-28～01-10 试点启动90%；W13–14 01-11～01-24 复盘DCP4 100%。年底后日期为2027年；均为条件性计划。
- **Visualization**: 等宽节点表示阶段顺序，不是持续时间图或实际进度图。
- **Data class**: scenario；全部日期和百分比为计划。

#### Slide 12 - 开发阶段交付
- **Audience move**: 各工作流对W5–8的集成演示形成共同预期。
- **Layout**: 四列按周交付板，下方跨周模型与临床工作带。
- **Title**: 四周开发，每周交付一个可演示增量
- **Core message**: 数据、端侧、算法研究与医生工作台并行，不串行等待。
- **Content**: W5 11-16～22 授权/绑定/真实落库；W6 11-23～29 曲线/质量/画像/最小医生台；W7 11-30～12-06 建议/审核/投递/反馈；W8 12-07～13 集成/审计/降级/影子智能体；数据合格后启动训练，临床规则和试点准入从W1推进；验收整改可持续到12-27。
- **Data class**: scenario；日期为规划。

#### Slide 13 - 准入与验收
- **Audience move**: 明确哪些证据缺失会阻止患者入组。
- **Layout**: 四个验收关口按上下区分，底部DCP3停止条件。
- **Title**: 入组前同时通过数据、模型、安全和机构门槛
- **Core message**: 关键缺陷与适用准入未关闭时暂停入组。
- **Content**: 数据：真实授权接入、单位时间正确、去重恢复；拟议可获取事件正确率≥99%；模型：独立评估、证据和版本、失效降级；技术：跨用户隔离、关键安全场景、恢复演练，关键缺陷0；机构：适用审批、临床复核容量、异常责任与服务时段；拟议标准化延迟p95≤60秒，厂商延迟另列；指标在DCP2冻结。
- **Data class**: scenario；技术指标均为拟议验收目标。

#### Slide 14 - 完成度管理
- **Audience move**: 使用证据成熟度计算实际完成，而不是凭感觉报告。
- **Layout**: 左侧简单公式及成熟度序列，右侧七项工作包权重表。
- **Title**: 完成度按交付证据计算，当前基线为0%
- **Core message**: 计划曲线与实际进度分别记录，100%只代表首期试点范围。
- **Content**: 实际完成度＝各交付物权重×成熟度之和；成熟度0/0.25/0.5/0.75/1；需求10%、架构治理15%、采集20%、决策20%、用户干预15%、验证15%、运营复盘5%；20项WBS，总权重100%；文档按专属验收状态；每周更新负责人、证据、阻塞及下一步。
- **Visualization**: wbs-weights为七行权重表；成熟度为有序标签不按大小缩放。
- **Native-ready**: wbs-weights=no
- **Data class**: scenario；权重与成熟度为拟议管理口径，实际基线来源于用户。

### Part 4: Risks and Immediate Actions

#### Slide 15 - 关键依赖
- **Audience move**: 识别关键路径，知道失败时的降级和升级路径。
- **Layout**: 依赖/主责/决策三列风险表；最关键前两行突出。
- **Title**: 优先关闭外部依赖，避免开发完成却无法试点
- **Core message**: 接入、许可和准入不能由模拟数据或软件测试替代。
- **Content**: CGM授权缺失 技术＋渠道 DCP1/2阻塞；训练数据不足 算法＋数据 审定基线先行/模型影子；风险信息缺失 临床＋产品 限制模式/人工复核；机构准入未完成 临床＋合规 暂停入组；团队与复核容量不足 PDT 缩减高级功能或重排时间；安全事件立即升级PDT与临床负责人。
- **Visualization**: dependencies为五行风险记录表。
- **Native-ready**: dependencies=no

#### Slide 16 - 前两周行动
- **Audience move**: 把会议共识转成六项可分配任务和截止日期。
- **Layout**: 行动/角色/截止/证据四列表格；日期明确。
- **Title**: 前两周必须落实六项启动交付
- **Core message**: 11月1日前具名资源与接入路径可核验，才能通过DCP1。
- **Content**: C02团队预算与机构/PDT/11-01/负责人投入和承诺；C01人群与预期用途/产品＋临床/11-01/范围草案；C03厂商接入与训练数据/数据＋技术/11-01/接口与交付约定；用户原型/产品设计/11-01/主路径；风险问卷与建议边界/临床产品/11-01/审定草案；初版数据契约与沙箱/技术数据/11-01/字段和回放。后3项为早期草案，正式计划冻结在11-15。
- **Visualization**: first-two-weeks为六行行动表。
- **Native-ready**: first-two-weeks=no
- **Data class**: scenario；日期为拟议启动计划。

#### Slide 17 - 试点与周会
- **Audience move**: 了解试点扩大条件和持续管理节奏。
- **Layout**: 左侧试点分批和反馈闭环，右侧周会运行安排。
- **Title**: 小批试点先验证流程，再按证据扩大
- **Core message**: 使用与运行验证先行，短期观察不证明长期疗效。
- **Content**: 首批10–20人，服务与安全满足后扩至40–80；约4周观察，后入组随访可延长；记录接入、安全、理解、执行反馈与成本，健康变化探索性记录；周会看交付证据/偏差/阻塞/下一步，每两周集成演示，DCP记录决定与条件；异常及时升级，不等待周会；Q03、O01、O02负责试点与复盘。
- **Data class**: scenario；人数和时间均为试点容量假设。

#### Slide 18 - 会议行动收束
- **Audience move**: 离会前形成具名负责人和首批行动承诺。
- **Layout**: 大字行动结论，四项待落实资源横向清单，下方今日会议输出。
- **Title**: 今天落实负责人，本周启动四条关键路径
- **Core message**: 用具名责任、明确日期和验收证据把方案转成执行。
- **Closing impact**: 最终行动是任命PDT/技术/临床负责人并登记四类外部依赖；不使用空白谢谢页。
- **Content**: 团队预算、合作机构、CGM接口、训练数据；会议输出：具名岗位表、首期范围、20项WBS认领、风险与待决清单；本周开始执行，11-01 DCP1、11-15 DCP2；2027-01-10前启动试点（条件性目标）；交付文件已在GitHub归档，实际开发从0%起。
- **Data class**: scenario；未来日期为计划。

## X. Speaker Notes Requirements

- **Generation**: enabled
- **Filename**: match each SVG filename under notes/
- **Content**: 每页给出主结论、讲解要点、角色行动与关键限制；引用来源project-design.md v0.2及ipd-deliverables.csv，说明计划/待确认。不得编造机构、人员、模型性能或健康效果。
- **Total duration**: 约25分钟，讨论与任务认领另计
- **Notes style**: 清晰、务实、结论先行，适合项目内部讲解
- **Presentation purpose**: align, explain, mobilize, record and hand off
