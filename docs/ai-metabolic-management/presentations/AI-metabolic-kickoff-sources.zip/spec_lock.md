<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9

## communication
- primary_language: zh-CN
- audience: PDT负责人、产品设计、后端数据、客户端、算法、临床、QA合规与运营成员
- objective: 统一首期范围与软件协作链路，让各角色认领交付物、日期、验收证据和阻塞处理责任。
- core_message: 从零起步，12周内启动CGM与医生复核的受控试点，关键依赖先落实，未验证模型保持影子运行。
- consumption_mode: balanced

## mode
- mode: custom
- mode_references: pyramid, instructional
- mode_behavior: 开篇明确试点目标，按采集到医生审核反馈逐层解释，将机制转成交付责任、DCP门槛和当周行动。

## visual_style
- visual_style: custom
- visual_style_references: swiss-minimal, editorial
- visual_style_behavior: 精确矩形区域、细分隔线和大面积留白；目标及收束用非对称大字，模块页用有序链路，责任与日期用可扫描网格，无装饰阴影。

## colors
- background: #F4F7FA
- secondary_bg: #FFFFFF
- primary: #132E43
- accent: #087F8C
- secondary_accent: #D78B42
- body_text: #183247
- muted: #5A6E7D
- grid: #D9E3EA
- inverse: #FFFFFF
- warning: #A65B13

## typography
- font_family: Noto Sans CJK SC, Microsoft YaHei, Arial
- title_family: Noto Sans CJK SC, Microsoft YaHei, Arial
- body_family: Noto Sans CJK SC, Microsoft YaHei, Arial
- body: 24
- title: 38
- subtitle: 28
- lead: 28
- annotation: 18
- label: 20
- footnote: 14
- hero: 84
- cover: 56

## icons
- library: none
- inventory: none

## page_rhythm
- P01: anchor
- P02: anchor
- P03: dense
- P04: anchor
- P05: dense
- P06: dense
- P07: anchor
- P08: dense
- P09: dense
- P10: dense
- P11: anchor
- P12: dense
- P13: dense
- P14: dense
- P15: dense
- P16: dense
- P17: dense
- P18: breathing

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
- 将未来计划或拟议指标描述为已实现；虚构姓名、机构、模型性能或临床效果
